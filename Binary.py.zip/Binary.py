def decimal_to_binary(decimal_number):
    binary = ""
    num = decimal_number
    while num > 0:
        binary = str(num % 2) + binary
        num //= 2
    return binary if binary else "0"

def decimal_to_hex(decimal_number):
    hex_digits = "0123456789ABCDEF"
    hex_value = ""
    num = decimal_number
    while num > 0:
        hex_value = hex_digits[num % 16] + hex_value
        num //= 16
    return hex_value if hex_value else "0"

def binary_to_decimal(binary_number):
    decimal = 0
    power = 0
    for digit in reversed(binary_number):
        decimal += int(digit) * (2 ** power)
        power += 1
    return decimal

def binary_to_hex(binary_number):
    decimal = binary_to_decimal(binary_number)
    return decimal_to_hex(decimal)

def hex_to_decimal(hex_number):
    decimal = 0
    power = 0
    hex_digits = "0123456789ABCDEF"
    for digit in reversed(hex_number.upper()):
        decimal += hex_digits.index(digit) * (16 ** power)
        power += 1
    return decimal

def hex_to_binary(hex_number):
    decimal = hex_to_decimal(hex_number)
    return decimal_to_binary(decimal)

# Test script
if __name__ == "__main__":
    test_values = [10, "1010", "A"]
    print(f"decimal_to_binary({test_values[0]}): {decimal_to_binary(test_values[0])}")
    print(f"decimal_to_hex({test_values[0]}): {decimal_to_hex(test_values[0])}")
    print(f"binary_to_decimal('{test_values[1]}'): {binary_to_decimal(test_values[1])}")
    print(f"binary_to_hex('{test_values[1]}'): {binary_to_hex(test_values[1])}")
    print(f"hex_to_decimal('{test_values[2]}'): {hex_to_decimal(test_values[2])}")
    print(f"hex_to_binary('{test_values[2]}'): {hex_to_binary(test_values[2])}")
